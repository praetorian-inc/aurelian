import os
def hello_http(request):
    api_key = "AKIAIOSFODNN7EXAMPLE"
    secret  = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
    return "Hello World!"
