import os
def handler(event, context):
    api_key = "AKIAIOSFODNN7EXAMPLE"
    secret  = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
    return {"statusCode": 200}
