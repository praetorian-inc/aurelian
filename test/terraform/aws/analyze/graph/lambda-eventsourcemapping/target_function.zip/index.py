import boto3
import json

def handler(event, context):
    # This Lambda function demonstrates privilege escalation
    # It has AdministratorAccess through the role and can perform any AWS operation
    
    # Example privileged operation - list all IAM users (requires admin permissions)
    try:
        iam = boto3.client('iam')
        users = iam.list_users()
        
        print(f"Privilege escalation successful! Found {len(users['Users'])} IAM users:")
        for user in users['Users']:
            print(f"  - {user['UserName']}")
            
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Privilege escalation via Lambda Event Source Mapping successful!',
                'user_count': len(users['Users']),
                'triggered_by': 'DynamoDB Stream Event'
            })
        }
    except Exception as e:
        print(f"Error during privilege escalation: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e)
            })
        }
