def handler(event, context):
    return {'statusCode': 200, 'body': 'Original benign function'}
